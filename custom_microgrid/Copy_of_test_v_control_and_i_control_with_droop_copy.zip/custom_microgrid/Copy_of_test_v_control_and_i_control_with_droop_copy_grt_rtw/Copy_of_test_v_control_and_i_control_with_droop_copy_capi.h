/*
 * Copy_of_test_v_control_and_i_control_with_droop_copy_capi.h
 *
 * Code generation for model "Copy_of_test_v_control_and_i_control_with_droop_copy".
 *
 * Model version              : 1.181
 * Simulink Coder version : 8.13 (R2017b) 24-Jul-2017
 * C source code generated on : Sun Sep  9 21:28:53 2018
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objective: Execution efficiency
 * Validation result: Passed (6), Warnings (6), Error (0)
 */

#ifndef RTW_HEADER_Copy_of_test_v_control_and_i_control_with_droop_copy_capi_h
#define RTW_HEADER_Copy_of_test_v_control_and_i_control_with_droop_copy_capi_h
#include "Copy_of_test_v_control_and_i_control_with_droop_copy.h"

extern void
  Copy_of_test_v_control_and_i_control_with_droop_copy_InitializeDataMapInfo
  (RT_MODEL_Copy_of_test_v_contr_T *const Copy_of_test_v_control_and_i_M,
   B_Copy_of_test_v_control_and__T *Copy_of_test_v_control_and_i__B,
   DW_Copy_of_test_v_control_and_T *Copy_of_test_v_control_and_i_DW,
   X_Copy_of_test_v_control_and__T *Copy_of_test_v_control_and_i__X);

#endif                                 /* RTW_HEADER_Copy_of_test_v_control_and_i_control_with_droop_copy_capi_h */

/* EOF: Copy_of_test_v_control_and_i_control_with_droop_copy_capi.h */
